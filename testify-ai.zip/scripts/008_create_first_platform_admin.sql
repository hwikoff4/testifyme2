-- Create your first platform admin
-- Replace 'YOUR_USER_ID' with your actual user ID from auth.users

-- To find your user ID, run:
-- SELECT id, email FROM auth.users;

-- Then insert into platform_admins:
-- INSERT INTO public.platform_admins (user_id)
-- VALUES ('YOUR_USER_ID');

-- Example:
-- INSERT INTO public.platform_admins (user_id)
-- VALUES ('a1b2c3d4-e5f6-7890-abcd-ef1234567890');
